import React from 'react'

export default class CityList extends React.Component {
  render() {
    return <div>这是城市选择页面</div>
  }
}
