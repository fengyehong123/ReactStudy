// 获取环境变量中配置的URL地址
export const BASE_URL = process.env.REACT_APP_URL
